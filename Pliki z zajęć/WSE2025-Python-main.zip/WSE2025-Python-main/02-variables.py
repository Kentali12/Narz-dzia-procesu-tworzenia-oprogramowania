# v1 = 4
# v2 = 4.0
# v3 = 4.5
# v4 = "4"
# v5 = None
# v6 = True
# print(v1, type(v1))
# print(v2, type(v2))
# print(v3, type(v3))
# print(v4, type(v4))
# print(v5, type(v5))
# print(v6, type(v6))

# number1 = 2
# number2 = 4
# print(number1, "+", number2, "=", number1 + number2)
# print(f"{number1} - {number2} = {number1 - number2}")
# print(f"{number1} * {number2} = {number1 * number2}")
# print(f"{number1} / {number2} = {number1 / number2}")
# print(f"{number2} % {number1} = {number2 % number1}")
# print(f"{number2} ** {number1} = {number2 ** number1}")
# number1, number2 = number2+2, number1-1
# print(number1, number2,)

# v7 = 36
# v8 = 64
# print(v7, id(v7))
# print(v8, id(v8))
# v9 = 36
# print(v9, id(v9))
# v9 = 64
# print(v9, id(v9))

# v10 = print
# v10("hello")
# print = "bye"
# v10(print)

int1 = 256
int2 = 0x100
int3 = 0o400
int4 = 0b100000000
print(int1, int2, int3, int4)

float1 = 100.
float2 = 0.10
float3 = .10
float4 = 1e4
print(float1, float2, float3, float4)
