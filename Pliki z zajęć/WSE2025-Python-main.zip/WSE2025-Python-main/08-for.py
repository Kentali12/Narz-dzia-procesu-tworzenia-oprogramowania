# numbers = [51, 84, -45, 646, 2, 45, 98]
# for number in numbers:
#     if number % 2 != 0:
#         print(number, end="; ")

for i in range(40):
    print(i, end=" ")
print()
for i in range(-10, 11):
    print(i, end=" ")
print()
for i in range(0, 11, 2):
    print(i, end=" ")
print()
for i in range(10, -11, -2):
    print(i, end=" ")
