def avg(n1, n2):
    return (n1 + n2) / 2
print(avg(2,3))
a = 4
b = 16
c = avg(a,b)
print(c)
